# 必須演習：minimum_minutesの30を60へ変更。実行前に残るIDを予想する。
# 第6回：必要な値を確かめてから分析用CSVを作る
library(readr)
library(dplyr)

# A 読む・確認する（work全体を開いて授業タスクで実行）
source_file <- "exercises/lesson06/data/study_records.csv"
column_types <- cols(id = col_character(), place = col_character(),
                     study_minutes = col_double(), quiz_score = col_double())
records <- read_csv(source_file, col_types = column_types, na = "",
                    show_col_types = FALSE, progress = FALSE)
print(records)
print(dim(records))
print(names(records))
print(sapply(records, class))
print(colSums(is.na(records)))

# B 必要な2列がある記録を残す（0は欠損ではない）
complete <- records |>
  filter(!is.na(study_minutes), !is.na(quiz_score))
cat("欠損処理後の件数:", nrow(complete), "\n")
print(complete$id)

# C 条件で選び、分を時間へ換算する
minimum_minutes <- 30
selected <- complete |>
  filter(study_minutes >= minimum_minutes) |>
  select(id, study_minutes, quiz_score) |>
  mutate(study_hours = study_minutes / 60)
print(selected)

# D 元CSVと別の場所へ保存して読み直す
output <- "exercises/lesson06/output"
dir.create(output, recursive = TRUE, showWarnings = FALSE)
output_file <- file.path(output, "exercise06_r.csv")
write_csv(selected, output_file)
reloaded <- read_csv(output_file,
                     col_types = cols(id = col_character(), .default = col_double()),
                     show_col_types = FALSE, progress = FALSE)
cat("再読込の件数:", nrow(reloaded), "\n")
print(names(reloaded))
cat("保存前と一致:", isTRUE(all.equal(as.data.frame(selected),
                                      as.data.frame(reloaded))), "\n")
cat("保存先:", output_file, "\n")
