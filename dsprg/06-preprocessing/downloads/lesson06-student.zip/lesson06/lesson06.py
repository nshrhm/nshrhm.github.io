# 第6回：必要な値を確かめてから分析用CSVを作る
from pathlib import Path
import pandas as pd

# A 読む・確認する（work全体を開いて授業タスクで実行）
source = Path("exercises/lesson06/data/study_records.csv")
column_types = {"id": "string", "place": "string",
                "study_minutes": "float64", "quiz_score": "float64"}
records = pd.read_csv(source, dtype=column_types,
                      keep_default_na=False, na_values=[""])
print(records)
print("行数・列数:", records.shape)
print("列名:", records.columns.tolist())
print("型:", records.dtypes)
print("欠損件数:", records.isna().sum())

# B 必要な2列がある記録を残す（0は欠損ではない）
complete = records.dropna(subset=["study_minutes", "quiz_score"])
print("欠損処理後の件数:", len(complete))
print("欠損処理後のID:", complete["id"].tolist())

# C 条件で選び、分を時間へ換算する
minimum_minutes = 30
selected = complete.loc[
    complete["study_minutes"] >= minimum_minutes,
    ["id", "study_minutes", "quiz_score"]
].copy()
selected["study_hours"] = selected["study_minutes"] / 60
print("条件抽出後:")
print(selected)

# D 元CSVと別の場所へ保存して読み直す
output = Path("exercises/lesson06/output")
output.mkdir(parents=True, exist_ok=True)
output_file = output / "lesson06_python.csv"
selected.to_csv(output_file, index=False)
reloaded = pd.read_csv(output_file, dtype={"id": "string"})
print("再読込の件数:", len(reloaded))
print("再読込の列名:", reloaded.columns.tolist())
print("保存前と一致:", selected.reset_index(drop=True).equals(reloaded))
print("保存先:", output_file)
