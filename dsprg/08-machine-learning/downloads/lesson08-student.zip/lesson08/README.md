# 第8回 機械学習の演習

このフォルダーを `work/exercises/lesson08/` に置き、VS Codeでwork全体を開きます。ZIP同梱の `lecture_note_08.md` をCtrl+Shift+Vで表示してください。まず `lesson08.py` と `lesson08.R` を授業タスクで実行します。

主言語Pythonなら `exercise08.py` と `verify.R`、主言語Rなら `exercise08.R` と `verify.py` を完成します。`data/equipment.csv` は架空の設備データ80行です。元データを書き換えず、主言語の結果は `output/validation_predictions.csv` に保存します。

両コード全文・主言語・実行状況・振り返りをFormsへ提出します。PDF・CSVの添付提出は不要です。提出先と期限は担当教員の案内に従ってください。
