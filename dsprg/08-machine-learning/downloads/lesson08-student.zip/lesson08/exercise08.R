# 第8回：訓練平均を固定して評価する。work全体を開いて実行します。
library(readr)
library(dplyr)

records <- read_csv("exercises/lesson08/data/equipment.csv", show_col_types = FALSE)
print(dim(records))
print(sapply(records, class))
print(colSums(is.na(records)))
train <- filter(records, split == "train")
validation <- filter(records, split == "validation")
baseline <- mean(train$energy_kwh)
print(train$id)
print(validation$id)
cat("訓練件数", nrow(train), "\n")
cat("検証件数", nrow(validation), "\n")
cat("訓練平均 kWh", baseline, "\n")
train_error <- abs(train$energy_kwh - baseline)
train_mae <- mean(train_error)
cat("訓練MAE kWh", train_mae, "\n")

# 変更前に検証MAEを予想してください。
# 1 訓練平均baselineを変えず、検証行の絶対誤差とMAEを計算・表示する。
# 2 主言語では検証行のid, energy_kwh, prediction_kwh, absolute_error_kwhを
#   output/validation_predictions.csvへ保存する（ノート§6）。
# 3 指定3行を手計算し、予想→実測→説明をFormsに記す。
