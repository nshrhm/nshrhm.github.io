# 第8回：訓練平均を固定して評価する。work全体を開いて実行します。
from pathlib import Path
import pandas as pd

source = Path("exercises/lesson08/data/equipment.csv")
records = pd.read_csv(source)
print(records.shape)
print(records.dtypes)
print(records.isna().sum())
train = records[records["split"] == "train"].copy()
validation = records[records["split"] == "validation"].copy()
baseline = train["energy_kwh"].mean()
print("訓練ID", train["id"].tolist())
print("検証ID", validation["id"].tolist())
print("訓練件数", len(train))
print("検証件数", len(validation))
print("訓練平均 kWh", baseline)
train_error = (train["energy_kwh"] - baseline).abs()
train_mae = train_error.mean()
print("訓練MAE kWh", train_mae)

# 変更前に検証MAEを予想してください。
# 1 訓練平均baselineを変えず、検証行の絶対誤差とMAEを計算・表示する。
# 2 主言語では検証行のid, energy_kwh, prediction_kwh, absolute_error_kwhを
#   output/validation_predictions.csvへ保存する（ノート§6）。
# 3 指定3行を手計算し、予想→実測→説明をFormsに記す。
