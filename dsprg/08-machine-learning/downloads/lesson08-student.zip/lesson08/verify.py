from pathlib import Path
import pandas as pd

# 照合用：元CSVから自分の言語で独立に計算します（ノート§7）。
# 1 data/equipment.csvを読む。パスはworkからの相対パス。
# 2 trainとvalidationのID・件数を表示する。
# 3 trainのenergy_kwhの平均を求め、固定する。
# 4 trainとvalidationそれぞれの絶対誤差の平均を表示する。
# 主言語の出力CSVを読まない。CSV保存は不要。
print("照合用の工程を実装してください。")
