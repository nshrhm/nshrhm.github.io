# 第9回 学生用ファイル

ZIP内のlesson09をwork/exercises/へ置き、work全体をVS Codeで開きます。lesson09.pyとlesson09.Rを各授業タスクで実行し、PNGはoutputから開きます。

主言語のexercise09と他方のverifyで、予測入力2・4・6時間を3・5・7時間へ変更します。学習はtrain60行・稼働時間一列・切片ありのままです。主言語でCSVとPNGを保存し、他言語は元CSVから独立に照合します。

詳細は同梱のlecture_note_09.mdを参照してください。主例と演習の出力名は同じなので実行ごとに置き換わります。元データは変更しません。提出は両コード全文と振り返りをFormsへ。PDF・CSV・PNGの添付提出はありません。
