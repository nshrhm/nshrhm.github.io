# 第9回：work全体を開き、授業タスクでファイル全体を実行します。
from pathlib import Path
import pandas as pd
from sklearn.linear_model import LinearRegression

records = pd.read_csv("exercises/lesson09/data/equipment.csv")
print(records.shape)
print(records.isna().sum())
train = records[records["split"] == "train"].copy()
print("訓練ID", train["id"].tolist())
print("訓練件数", len(train))
print("稼働時間範囲", train["operating_hours"].min(), train["operating_hours"].max())
x = train[["operating_hours"]]
y = train["energy_kwh"]
model = LinearRegression()
model.fit(x, y)
print("切片 kWh", model.intercept_)
print("傾き kWh/h", model.coef_[0])
# 変更演習：予測入力だけを3・5・7時間へ変更します。
queries = pd.DataFrame({"operating_hours": [2.0, 4.0, 6.0]})
queries["prediction_kwh"] = model.predict(queries[["operating_hours"]])
print(queries.to_string(index=False))
