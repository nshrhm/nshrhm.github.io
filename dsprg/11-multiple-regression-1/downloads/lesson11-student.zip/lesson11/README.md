# 第11回 学生用ファイル

ZIP内のlesson11をwork/exercises/へ置き、work全体を開きます。lesson11.pyとlesson11.Rを授業タスクで実行します。主例は二変数の完成例です。

主言語のexercise11と他方のverifyで、変更対象モデルに処理量を追加します。Pythonは説明変数リスト、Rは式を一箇所変更します。比較用単回帰、訓練60行、目的変数、検証20行は維持します。

主言語はoutput/evaluation.csvとresiduals.pngを保存し、他方は元CSVから独立照合します。同じ出力名は再実行で置き換わるため、比較用の結果をメモや別名コピーで残してください。元CSVは変更しません。詳細は同梱lecture_note_11.md。Formsへ両コード全文・実行状況・振り返りを提出し、添付提出はありません。
