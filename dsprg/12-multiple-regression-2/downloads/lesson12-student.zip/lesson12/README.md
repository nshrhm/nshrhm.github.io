# 第12回の実行と保存

ZIPの `lesson12/` を `work/exercises/` に置き、VS Codeで `work` 全体を開きます。既存のPython／R実行タスクを使います。

1. `lecture_note_12.md` を読み、`lesson12.py` と `lesson12.R` の主例を実行。
2. 主言語の `exercise12.py` または `.R` と、照合言語の `verify.py` または `.R` を使う。
3. 比較表を読んで、両方の選択指定を `hours` から `both` へ変更する。
4. 主言語の `output/comparison.csv`、`evaluation.csv`、`comparison.png` を確認する。
5. 独立照合・手計算・振り返りを行い、両コード全文をFormsへ提出する。

再実行は同じoutputを更新します。最終確認データは教員実演用で、学生の操作は不要です。入力CSVは変更しません。締切・実Forms URLは教員の案内に従ってください。
